# html表格

> 表格由 \<table> 标签来定义。每行（由 \<tr> 标签定义），每行的单元格（由 \<td> 标签定义）

表格示例

```html
<table border="1">
    <tr>
        <td>row 1, cell 1</td>
        <td>row 1, cell 2</td>
    </tr>
    <tr>
        <td>row 2, cell 1</td>
        <td>row 2, cell 2</td>
    </tr>
</table>
```



属性

| 属性名      | 含义                                     | 常用属性值        |
| ----------- | ---------------------------------------- | ----------------- |
| border      | 设置表格边框，默认为0                    | 像素值            |
| cellspacing | 设置单元格与单元格边框之间的空白间距     | 像素值（默认2px） |
| cellpadding | 设置单元格内容与单元格边框之间的空白间距 | 像素值（默认1px） |
| width       | 设置表格的宽度                           | 像素值            |
| height      | 设置表格的高度                           | 像素值            |
| align       | 设置表格再网页中的水平对齐方式           | left,center,right |



## 表头单元格标签th

一般表头单元格位于表格的第一行或第一列，并且文本加粗居中

```html
<table>
    <tr>
        <th>1</th>
        <th>2</th>
    </tr>
</table>
```



## 表头标题caption

语法：

```html
<table>
   <caption>我是表格标题</caption>
</table>
```



## 合并单元格

> 跨行合并：rowspan=”合并单元格的个数”
>
> 跨列合并：colspan=”合并单元格的个数”

```html
<table border="1" width="500px" height="300px" cellspacing="0" cellpadding="0" align="center">
	<caption>
		<b>个人简历</b>
	</caption>
	<tr>
		<td>姓名</td>
		<td>性别</td>
		<td>年龄</td>
		<td rowspan="2" align="center">照片</td>
	</tr>
	<tr>
		<td>身高</td>
		<td>民族</td>
		<td>婚姻</td>
		
	</tr>
	<tr>
		<th>个人简历</th>
		<td>个人简历</td>
		<td>个人简历</td>
		<td>个人简历</td>
	</tr>
	<tr>
		<th>个人作品</th>
		<td colspan="3" align="center">个人作品</td>
	</tr>
</table>
```



合并单元格顺序

**合并的顺序我们按照 先上 后下 先左 后右 的顺序** 