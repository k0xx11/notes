﻿## html基本结构

```html
<!DOCTYPE html>
<!-- 声明文档类型 -->
<html lang="en">  <!-- lang属性定义页面语言 -->
<head>
    <meta charset="utf-8">
    <!-- 利用UTF-8格式来解析 -->
    <title></title>
</head>
<body></body>
</html>
```

## html头部

html头部由head标签定义，它是所有头部元素的容器



link标签可以引入css和设置网页图标

```html
<!-- 引入css-->
<link rel="stylesheet" type="text/css" href="mystyle.css">
<!-- <link>标签设置网页图标 -->
<link rel="shortcut icon" href="picture_url">
```



title标签定义了文档标题

```html
<title>文档标题</title>
```



meta标签定义了一些基本的元数据。

> META 元素通常用于指定网页的描述，关键词，文件的最后修改时间，作者，和其他元数据。
>
> 元数据可以使用于浏览器（如何显示内容或重新加载页面），搜索引擎（关键词），或其他Web服务。



meta标签使用实例

标签定义字符集,没有这个网页就会出现乱码:

```html
<meta charsret="utf-8">
```



为搜索引擎定义关键词:

```html
<meta name="keywords" content="Python Html">
```



为网页定义描述内容:

```html
<meta name="description" content="web安全笔记分享">
```



定义网页作者:

```html
<meta name="author" content="k0xx">
```



每30秒钟刷新当前页面:

```html
<meta http-equiv="refresh" content="30">
```



style标签

设置css样式

```html
<style type="text/css">
body {background-color:yellow}
p {color:blue}
</style>
```



base标签

> 可设置网页内所有标签的打开方式

```html
<base href="http://www.runoob.com/images/" target="_blank">
```



script标签

> 引入外部js文件

```html
<script src="https://www.com.cn/index.js" type='text/javascript'></script>
```



## 注释

```html
语法：<!--这是一个注释-->
```



## 标题标签h

> HTML标题通过\<h1> -\<h6> 标签来定义的

```html
<h1>1</h1>
<h2>2</h2>
<h3>3</h3>
<h4>4</h4>
<h5>5</h5>
<h6>6</h6>
```



## 段落标签P

```html
<p>这是一个段落</p>
```



## 换行标签br

```html
<br />
```



## 水平线标签hr

```html
<hr />
```



## div和span

```html
<div>1</div> <span>1/span>
```

区别：

| \<div>\</div>   | div标签  | 用来布局的，但是现在一行只能放一个div |
| --------------- | -------- | ------------------------------------- |
| \<span>\</span> | span标签 | 用来布局的，一行上可以放好多个span    |



## 文本格式化标签

| 标签                           | 显示效果                                        |
| ------------------------------ | ----------------------------------------------- |
| \<b>\</b>和\<strong>\</strong> | 文字以粗体方式显示（XHTML推荐使用strong）  记住 |
| \<i>\</i>和\<em>\</em>         | 文字以斜体方式显示（XHTML推荐使用em）  记住     |
| \<s>\</s>和\<del>\</del>       | 文字以加删除线方式显示（XHTML推荐使用del）      |
| \<u>\</u>和\<ins>\</ins>       | 文字以加下划线方式显示（XHTML不赞成使用u）      |
| \<sup>                         | 定义上标字                                      |
| \<sub>                         | 定义下标字                                      |

> b 只是加粗 strong 除了可以加粗还有 强调的意思， 语义更强烈。



## pre标签

> 保留文本原来的格式

```html
<pre>来自</pre>
```



## base标签

> 设置整体链接的打开状态，需要写到head里面
>
> 所有链接都会默认添加target="_blank"

```html
<base href="http://www.baidu.com" target="_blank">
```

target属性值

| 值          | 描述                                 |
| :---------- | ------------------------------------ |
| _blank      | 在新窗口中打开被链接文档。           |
| _self       | 默认。在相同的窗口中打开被链接文档。 |
| _parent     | 在父框架集中打开被链接文档。         |
| _top        | 在整个窗口中打开被链接文档。         |
| *framename* | 在指定的框架中打开被链接文档。       |



## 链接标签a

```html
<a href="https://www.baidu.com">百度</a>
```

| 属性     | 作用                                                         |
| -------- | ------------------------------------------------------------ |
| href     | 用于指定链接目标的url地址，（必须属性）                      |
| href="#" | #代表空链接                                                  |
| target   | 用于指定链接页面的打开方式，其取值有*self和*blank两种，其中*self为默认值，*blank为在新窗口中打开方式。 |

> target属性值

| 值          | 描述                                 |
| :---------- | ------------------------------------ |
| _blank      | 在新窗口中打开被链接文档。           |
| _self       | 默认。在相同的窗口中打开被链接文档。 |
| _parent     | 在父框架集中打开被链接文档。         |
| _top        | 在整个窗口中打开被链接文档。         |
| *framename* | 在指定的框架中打开被链接文档。       |



### 扩展

1.描点

```html
<a href="#id名"></a>
<p id="id名">11</p>
```

2.图片链接

```html
<a href="URL"><img src="#"></a> #img图片标签
```

3.电子邮件链接

> **注意:** 单词之间空格使用 %20 代替，以确保浏览器可以正常显示文本。

```html
<a href="mailto:someone@example.com?Subject=Hello%20again" target="_top">
发送邮件</a>
```



# 图片标签img

```html
<img src="图片URL" />
```

| 属性    | 属性值            | 描述                           |
| ------- | ----------------- | ------------------------------ |
| src     | 图片路径          | 必要属性                       |
| alt     | 自定义            | 图片不见时，显示描述图片的文字 |
| width   | 自定义            | 设置图片宽度，一般单位为px     |
| height  | 自定义            | 设置图片高度，一般单位为px     |
| border  | 自定义            | 设置图片的边框，一般为0        |
| align   | 有:left左,right右 | 使图片浮动至段落的左边或右边。 |
| title   | 自定义            | 悬停img图片标签提示显示文字    |
| src="#" | #                 | 代表空图片                     |

图片格式

> jpg 有损压缩 影响画质 图片小
> png 无损压缩 不影响画质 大 有透明通道
> gif 动图

实例

```html
<img src="#" >
<img src="#" alt="图片" width="300px" height="300px" boredr="2px" title="图片">
```



## 路径

路径分绝对路径和相对路径，相对路径又分同一级路径，上一级路径，下一级路径

### 绝对路径

绝对路径以Web站点根目录为参考基础的目录路径。之所以称为绝对，意指当所有网页引用同一个文件时，所使用的路径都是一样的。

> “D:\web\img\logo.gif”，或完整的网络地址，例如“http://www.itcast.cn/images/logo.gif”。



### 相对路径



| 路径分类   | 符号  | 说明                                                         |
| ---------- | ----- | ------------------------------------------------------------ |
| 同一级路径 |       | 只需输入图像文件的名称即可，如src='1.png'。                  |
| 下一级路径 | “/”   | 图像文件位于HTML文件同级文件夹下（例如文件夹名称为：images）  如src='image/2.png'。 |
| 上一级路径 | “../” | 在文件名之前加入“../”  ，如果是上两级，则需要使用 “../ ../”，以此类推，如src='../3.png'。 |



## 特殊符号

| **显示结果** | **描述**     | **实体名称** | **实体编号** |
| ------------ | ------------ | ------------ | ------------ |
|              | 空格         | \&nbsp;      | \&#160;      |
| <            | 小于号(常用) | \&lt;        | \&#60;       |
| >            | 大于号(常用) | \&gt;        | \&#62;       |
| &            | 和号         | \&amp;       | \&#38;       |
| "            | 引号         | \&quot;      | \&#34;       |
| '            | 撇号         | \&apos;      | \&#39;       |
| ¢            | 分           | \&cent;      | \&#162;      |
| £            | 镑           | \&pound;     | \&#163;      |
| ￥           | 人民币/日元  | \&yen;       | \&#165;      |
| €            | 欧元         | \&euro;      | \&#8364;     |
| §            | 小节         | \&sect;      | \&#167;      |
| ©            | 版权         | \&copy;      | \&#169;      |
| ®            | 注册商标     | \&reg;       | \&#174;      |
| ™            | 商标         | \&trade;     | \&#8482;     |
| ÷            | 除号         | \&divide;    | \&#247;      |



## 颜色

颜色有用颜色名/16进制/rgb表示

示例

```css
红色 颜色名red 16进制#FF0000	 rgb rgb(255,0,0)
```



## 内联框架iframe

```html
<iframe src="URL"></iframe>
```

| 属性名      | 属性值                                | 作用                     |
| ----------- | ------------------------------------- | ------------------------ |
| src         | url                                   | 必要属性                 |
| width       | 单位为px（像素【默认】）或%（百分比） | 设置框架显示宽度         |
| height      | 单位为px（像素【默认】）或%（百分比） | 设置框架显示高度         |
| frameborder | 1【默认】：开启边框；0：移除边框。    | 属性用于定义是否显示边框 |

```html
<iframe src="https://www.w3cschool.cn" width="300" height="300" frameborder="0">
</iframe>
```

使用iframe 作为链接的目标(traget)

> 链接的target属性必须引用iframe 的name属性

示例:

```html
<iframe src="demo_iframe.htm" name="iframe_a"></iframe>
<p><a href="http://www.w3school.com.cn" target="iframe_a">W3School.com.cn</a></p
```



## html框架frameset 

```html
 语法： <frameset rows="50%,*">
```

> \<frame src="[http://www.baidu.com](http://www.baidu.com/)" scrolling="no"/> \<frame src="[http://www.soso.com](http://www.soso.com/)" /> \</frameset> 
>
> frameset 不能在body内使用 frame 一般都是在frameset中使用



属性：

>  cols 定义框架集中列的数目和尺寸
>
>  rows 定义框架集中行的数目和尺寸eg:rows="50%,*" 
>
> *就会复制前面的50% scrolling 滚动条 
>
> eg：scrolling="no" auto 在需要的情况下出现滚动条（默认值）。
>
>  yes 始终显示滚动条（即使不需要）。 no 从不显示滚动条（即使需要）

```html
<frameset rows="50%,*">

<frame src="http://www.baidu.com" scrolling="no"/>
<frame src="http://www.soso.com" />
</frameset>
```

