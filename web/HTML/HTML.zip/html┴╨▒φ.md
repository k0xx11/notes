html列表有有序列表、无序列表和自定义列表

### 有序列表ol

有序列表使用ol标签，数字表示

```
<ol>
<li>1</li>
<li>1</li>
</0l>
```

属性

> type="A" 大写字母表示
>
> type="a" 小写字母表示
>
> type="I" 大写罗马数字表示
>
> type="i" 小写罗马数字表示



### 无序列表ul

无序列表使用ul标签，粗体圆点表示

```
<ul>
<li>1</li>
<li>1</li>
</ul>
```

属性

> type="square" 正方形列表
>
> type="circle"  圆圈列表
>
> type="disc" 圆点列表

### 自定义列表dl

```
<dl>
<dt>Coffee</dt>
<dd>- black hot drink</dd>
<dt>Milk</dt>
<dd>- white cold drink</dd>
</dl>
```

