## 概述

在HTML中，一个完整的表单通常由表单控件（也称为表单元素）、提示信息和表单域3个部分构成。



## 表单控件input

语法：

```html
<input type="属性值" value="你好">
```

| type属性 | 属性值       | 描述                        |
| -------- | ------------ | --------------------------- |
|          | text         | 单行文本输入框              |
|          | password     | 密码输入框                  |
|          | radio        | 单选框                      |
|          | checkbox     | 复选框                      |
| type     | button       | 普通按钮                    |
|          | submit       | 提交按钮                    |
|          | reset        | 重置按钮                    |
|          | image        | 图片形式的提交按钮          |
|          | file         | 文件域/文件上传             |
| name     | 由用户自定义 | 控件的名称                  |
| value    | 由用户自定义 | input控件中的默认文本值     |
| size     | 正整数       | input控件在页面中的显示宽度 |
| checked  | checked      | 定义选择控件默认被选中的项  |
| maxlenth | 正整数       | 控件允许输入的最大字符数    |



文本框

```html
<input type="text" name="zhao">
```



密码输入框

```html
<input type="password"name="passwd">
```



单选框

```html
<input type="radio">
```



复选框

```html
男<input type="checkbox">
女<input type="checkbox">
```



普通按钮

```html
<input type="button" value="按钮名称" name="bp">
```



提交按钮

```html
<input type="submit" value="按钮名称" name="tj">
```



文本域（文件上传）

```html
<input type="file" value="按钮名称" name="upload">
```



## form表单域

语法：

```html
<form action="url地址" method="提交方式" name="表单名称"> #不写name值，服务器获取不到参数
  各种表单控件
</form>
```

常用属性：

| 属性   | 属性值   | 作用                                               |
| ------ | -------- | -------------------------------------------------- |
| action | url地址  | 用于指定接收并处理表单数据的服务器程序的url地址。  |
| method | get/post | 用于设置表单数据的提交方式，其取值为get或post。    |
| name   | 名称     | 用于指定表单的名称，以区分同一个页面中的多个表单。 |



### enctype属性

> 规定在将表单数据发送到服务器之前如何对其进行编码。

> 注意：只有`method=”post”`时才使用enctype属性。
>
> enctype属性值有：
>
> - application/x-www-form-urlencoded:【**普通表单默认**】在发送前对所有字符进行编码（将空格转换为”+”符号，特殊字符转换为ASCII HEX值）。
>
> - multipart/form-data:不对字符编码。当使用有文件上传控件的表单时，该值是必须的(**上传文件时编码**)
>
> - text/plain **不进行编码**



## HTML特殊表单元素

### 下拉列表select

> \<select>标签定义了下拉选项列表。
>
> \<select>中的\<option>标签定义列表中的可用选项。
>
> 在option 中定义selected =” selected “时，当前项即为默认选中项。



```html
<select>
    <option value="1">Apple</option>
    <option value="2">Banana</option>
    <option value="3">Orange</option>
    <option selected="selected">4</option>
</select>
```



### 文本域textarea

> \<textarea>标签定义文本域。
>
> cols、rows属性分别规定了文本区域内可见的宽度和高度。
>
> cols 每行的字符数
> rows 显示的行数

```html
<textarea rows="3" cols="20">input something</textarea>
```



## HTML其他表单元素

### \<label>

> \<label>标签定义了\<input>元素的标签，一般为输入标题。

```html
<form action="label_form.php">
    <label for="1">Male</label>
    <input type="radio" name="sex" id="1" value="male"><br/>
    <label for="2">Female</label>
    <input type="radio" name="sex" id="2" value="female"><br/>
    <input type="submit" value="I am a human.">
</form>
```

> 点击\<label>标签，浏览器会自动将焦点转移到和标签相关的表单控件上。



### \<button>

> \<button>标签定义一个按钮。
>
> 在\<button>元素内部可以放置内容，如文本或图像。
>
> \<button>type属性值有：
>
> - submit：【默认】提交按钮
>
> - button：可点击按钮
>
> - reset：重置按钮

```html
<button type="button">a magic button!</button>
```



### \<fieldset>

> \<fieldset>标签定义了一组相关的表单元素，并使用外框包含起来。
>
> \<legend>标签定义了\<fieldset>元素的标题。



```html
<form>
    <fieldset>
        <legend>
            Author: 
        </legend>
        Name: <input type="text"><br/><br/>
        Telephone: <input type="text"><br/><br/>
        Email: <input type="text">
    </fieldset>
</form>
```

